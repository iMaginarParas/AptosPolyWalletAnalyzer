require('dotenv').config();
const { ethers } = require('ethers');
const axios = require('axios');

async function fetchWalletData(walletAddress) {
    const provider = new ethers.providers.JsonRpcProvider(process.env.POLYGON_RPC_URL);
    const balance = await provider.getBalance(walletAddress);

    const apiKey = process.env.POLYGONSCAN_API_KEY;
    const url = `https://api.polygonscan.com/api?module=account&action=txlist&address=${walletAddress}&startblock=0&endblock=99999999&sort=desc&apikey=${apiKey}`;
    
    const response = await axios.get(url);
    const transactions = response.data.result;

    return { balance, transactions };
}

function analyzeTransactions(transactions, walletAddress) {
    const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;
    const recentTxs = transactions.filter(tx => parseInt(tx.timeStamp) * 1000 > thirtyDaysAgo);

    let swapProfit = 0;
    let totalFees = 0;
    let buys = 0;
    let sells = 0;
    const uniqueTokens = new Set();

    recentTxs.forEach(tx => {
        totalFees += parseFloat(ethers.utils.formatEther(tx.gasPrice)) * parseFloat(tx.gasUsed);
        
        if (tx.from.toLowerCase() === walletAddress.toLowerCase()) {
            sells++;
        } else {
            buys++;
        }

        uniqueTokens.add(tx.to);
    });

    return {
        swapProfit,
        totalFees,
        totalProfit: swapProfit - totalFees,
        uniqueTokens: uniqueTokens.size,
        buys,
        sells
    };
}

function generateReport(walletAddress, balance, analysis) {
    const roi = (analysis.totalProfit / parseFloat(ethers.utils.formatEther(balance))) * 100;
    const winRate = (analysis.sells / (analysis.buys + analysis.sells)) * 100;

    return `
Wallet Analysis for ${walletAddress}:
💰 MATIC Balance: ${ethers.utils.formatEther(balance)} MATIC
💱 Swap Profit: ${analysis.swapProfit.toFixed(4)} MATIC
💸 Total Fees: ${analysis.totalFees.toFixed(4)} MATIC
📊 Total Profit (30d): ${analysis.totalProfit.toFixed(4)} MATIC
📈 ROI: ${roi.toFixed(2)}%
🎯 Win Rate: ${winRate.toFixed(2)}%

Last 30d Performance:
🔢 Unique Tokens: ${analysis.uniqueTokens}
🟢 Buys: ${analysis.buys}
🔴 Sells: ${analysis.sells}
    `;
}

async function analyzeWallet(walletAddress) {
    const { balance, transactions } = await fetchWalletData(walletAddress);
    const analysis = analyzeTransactions(transactions, walletAddress);
    return generateReport(walletAddress, balance, analysis);
}

const walletAddress = process.argv[2];
if (walletAddress) {
    analyzeWallet(walletAddress)
        .then(report => console.log(report))
        .catch(error => console.error('Error:', error));
} else {
    console.log('Please provide a wallet address.');
}